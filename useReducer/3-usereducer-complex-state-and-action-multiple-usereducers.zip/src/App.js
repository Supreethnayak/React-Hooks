import CounterThree from "./components/CounterThree";
import "./styles.css";

export default function App() {
  return (
    <div className="App">
      <CounterThree />
    </div>
  );
}
